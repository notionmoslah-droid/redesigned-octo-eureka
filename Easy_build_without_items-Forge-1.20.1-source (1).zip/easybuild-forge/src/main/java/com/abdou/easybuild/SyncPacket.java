package com.abdou.easybuild;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: what the preview needs to know (build mode, first point, mirror center). */
public class SyncPacket {
    public final boolean enabled;
    public final BlockPos first, center;

    public SyncPacket(boolean enabled, BlockPos first, BlockPos center) {
        this.enabled = enabled; this.first = first; this.center = center;
    }

    public SyncPacket(FriendlyByteBuf b) {
        this.enabled = b.readBoolean();
        this.first = b.readBoolean() ? b.readBlockPos() : null;
        this.center = b.readBoolean() ? b.readBlockPos() : null;
    }

    public void encode(FriendlyByteBuf b) {
        b.writeBoolean(enabled);
        b.writeBoolean(first != null); if (first != null) b.writeBlockPos(first);
        b.writeBoolean(center != null); if (center != null) b.writeBlockPos(center);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ClientState.enabled = enabled;
        ClientState.first = first;
        ClientState.center = center;
    }
}
