package com.abdou.easybuild;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SettingsPacket {
    public final boolean enabled, mx, mz, my, setCenter, undo;
    public final int mode, count, dx, dy, dz;

    public SettingsPacket(boolean enabled, int mode, boolean mx, boolean mz, boolean my, boolean setCenter,
                          int count, int dx, int dy, int dz, boolean undo) {
        this.enabled = enabled; this.mode = mode; this.mx = mx; this.mz = mz; this.my = my;
        this.setCenter = setCenter; this.count = count; this.dx = dx; this.dy = dy; this.dz = dz; this.undo = undo;
    }

    public SettingsPacket(FriendlyByteBuf b) {
        this(b.readBoolean(), b.readVarInt(), b.readBoolean(), b.readBoolean(), b.readBoolean(), b.readBoolean(),
                b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readBoolean());
    }

    public void encode(FriendlyByteBuf b) {
        b.writeBoolean(enabled); b.writeVarInt(mode); b.writeBoolean(mx); b.writeBoolean(mz); b.writeBoolean(my);
        b.writeBoolean(setCenter); b.writeVarInt(count); b.writeVarInt(dx); b.writeVarInt(dy); b.writeVarInt(dz);
        b.writeBoolean(undo);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) BuildHandler.applySettings(player, this);
    }
}
