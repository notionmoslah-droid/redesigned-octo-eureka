package com.abdou.easybuild.client;

import com.abdou.easybuild.ClientState;
import com.abdou.easybuild.EasyBuild;
import com.abdou.easybuild.Network;
import com.abdou.easybuild.Shapes;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = EasyBuild.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientForgeEvents {
    private static final int MAX_PREVIEW = 1500;

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        while (ClientModEvents.MENU_KEY.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new EasyBuildScreen());
        }
        while (ClientModEvents.TOGGLE_KEY.consumeClick()) {
            ClientState.enabled = !ClientState.enabled;
            if (!ClientState.enabled) ClientState.first = null;
            Network.CHANNEL.sendToServer(ClientState.packet(false, false));
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientState.reset();
    }

    /** Live preview: outlines of every block that will be placed. */
    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        if (!ClientState.enabled || mc.player == null || mc.level == null) return;
        if (!(mc.player.getMainHandItem().getItem() instanceof BlockItem)) return;

        List<BlockPos> blocks = compute(mc);
        if (blocks.isEmpty()) return;

        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buf.getBuffer(RenderType.lines());
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        int n = 0;
        for (BlockPos p : blocks) {
            if (n++ >= MAX_PREVIEW) break;
            LevelRenderer.renderLineBox(ps, vc, new AABB(p).inflate(0.002), 0.3f, 0.9f, 1.0f, 0.9f);
        }
        if (ClientState.mode != 0 && ClientState.first != null) {
            LevelRenderer.renderLineBox(ps, vc, new AABB(ClientState.first).inflate(0.01), 1.0f, 0.85f, 0.2f, 1.0f);
        }
        ps.popPose();
        buf.endBatch(RenderType.lines());
    }

    private static List<BlockPos> compute(Minecraft mc) {
        HitResult hr = mc.hitResult;
        if (!(hr instanceof BlockHitResult bhr) || hr.getType() != HitResult.Type.BLOCK) return List.of();
        BlockPos target = bhr.getBlockPos().relative(bhr.getDirection());
        List<BlockPos> base = List.of(target);
        if (ClientState.mode != 0 && ClientState.first != null) {
            base = Shapes.shape(ClientState.mode, ClientState.first, target);
            if (base == null) return List.of();
        }
        BlockPos center = ClientState.center != null ? ClientState.center : mc.player.blockPosition().below();
        return Shapes.repeat(Shapes.mirror(base, ClientState.mx, ClientState.mz, ClientState.my, center),
                ClientState.count, ClientState.dx, ClientState.dy, ClientState.dz);
    }
}
