package com.abdou.easybuild;

import net.minecraft.core.BlockPos;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Shape maths shared by the server (building) and the client (preview). */
public final class Shapes {
    public static final String[] MODES = {"Normal", "Line", "Wall", "Roof", "Filled Box"};
    public static final String[] MODES_AR = {"عادي", "خط", "جدار", "سقف", "صندوق ممتلئ"};
    public static final int MAX_BLOCKS = 4000;

    /** Returns null when the area is too large. */
    public static List<BlockPos> shape(int mode, BlockPos a, BlockPos b) {
        return switch (mode) {
            case 1 -> line(a, b);
            case 2 -> wall(a, b);
            case 3 -> roof(a, b);
            case 4 -> box(a, b);
            default -> List.of(b);
        };
    }

    public static List<BlockPos> line(BlockPos a, BlockPos b) {
        int dx = b.getX() - a.getX(), dy = b.getY() - a.getY(), dz = b.getZ() - a.getZ();
        int n = Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz)));
        List<BlockPos> out = new ArrayList<>();
        for (int i = 0; i <= n; i++) {
            double t = n == 0 ? 0 : (double) i / n;
            out.add(new BlockPos((int) Math.round(a.getX() + dx * t),
                    (int) Math.round(a.getY() + dy * t), (int) Math.round(a.getZ() + dz * t)));
        }
        return out;
    }

    /** Vertical wall: line on the ground from a to b, raised from the lower to the higher point. */
    public static List<BlockPos> wall(BlockPos a, BlockPos b) {
        int dx = b.getX() - a.getX(), dz = b.getZ() - a.getZ();
        int n = Math.max(Math.abs(dx), Math.abs(dz));
        int y0 = Math.min(a.getY(), b.getY()), y1 = Math.max(a.getY(), b.getY());
        if ((long) (n + 1) * (y1 - y0 + 1) > MAX_BLOCKS) return null;
        Set<BlockPos> out = new LinkedHashSet<>();
        for (int i = 0; i <= n; i++) {
            double t = n == 0 ? 0 : (double) i / n;
            int x = (int) Math.round(a.getX() + dx * t), z = (int) Math.round(a.getZ() + dz * t);
            for (int y = y0; y <= y1; y++) out.add(new BlockPos(x, y, z));
        }
        return new ArrayList<>(out);
    }

    /** Flat roof/floor at the height of the first point. */
    public static List<BlockPos> roof(BlockPos a, BlockPos b) {
        int x0 = Math.min(a.getX(), b.getX()), x1 = Math.max(a.getX(), b.getX());
        int z0 = Math.min(a.getZ(), b.getZ()), z1 = Math.max(a.getZ(), b.getZ());
        if ((long) (x1 - x0 + 1) * (z1 - z0 + 1) > MAX_BLOCKS) return null;
        List<BlockPos> out = new ArrayList<>();
        for (int x = x0; x <= x1; x++)
            for (int z = z0; z <= z1; z++) out.add(new BlockPos(x, a.getY(), z));
        return out;
    }

    public static List<BlockPos> box(BlockPos a, BlockPos b) {
        int x0 = Math.min(a.getX(), b.getX()), x1 = Math.max(a.getX(), b.getX());
        int y0 = Math.min(a.getY(), b.getY()), y1 = Math.max(a.getY(), b.getY());
        int z0 = Math.min(a.getZ(), b.getZ()), z1 = Math.max(a.getZ(), b.getZ());
        if ((long) (x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1) > MAX_BLOCKS) return null;
        List<BlockPos> out = new ArrayList<>();
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                for (int z = z0; z <= z1; z++) out.add(new BlockPos(x, y, z));
        return out;
    }

    public static List<BlockPos> mirror(List<BlockPos> list, boolean mx, boolean mz, boolean my, BlockPos c) {
        if (!(mx || mz || my) || c == null) return list;
        Set<BlockPos> out = new LinkedHashSet<>();
        for (BlockPos p : list) {
            int[] xs = mx ? new int[]{p.getX(), 2 * c.getX() - p.getX()} : new int[]{p.getX()};
            int[] ys = my ? new int[]{p.getY(), 2 * c.getY() - p.getY()} : new int[]{p.getY()};
            int[] zs = mz ? new int[]{p.getZ(), 2 * c.getZ() - p.getZ()} : new int[]{p.getZ()};
            for (int x : xs) for (int y : ys) for (int z : zs) out.add(new BlockPos(x, y, z));
        }
        return new ArrayList<>(out);
    }

    public static List<BlockPos> repeat(List<BlockPos> list, int count, int dx, int dy, int dz) {
        if (count <= 0) return list;
        Set<BlockPos> out = new LinkedHashSet<>();
        for (BlockPos p : list) {
            out.add(p);
            for (int i = 1; i <= count; i++) out.add(p.offset(dx * i, dy * i, dz * i));
            if (out.size() > MAX_BLOCKS * 2) break;
        }
        return new ArrayList<>(out);
    }
}
