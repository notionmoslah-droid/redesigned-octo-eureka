package com.abdou.easybuild.client;

import com.abdou.easybuild.ClientState;
import com.abdou.easybuild.EasyBuild;
import com.abdou.easybuild.Shapes;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.client.settings.KeyModifier;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = EasyBuild.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientModEvents {
    public static final String CATEGORY = "key.categories.easybuild";

    /** B = open the menu */
    public static final KeyMapping MENU_KEY = new KeyMapping("key.easybuild.menu",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CATEGORY);

    /** Ctrl+S = build mode on/off (plain S is "walk backwards" in Java) */
    public static final KeyMapping TOGGLE_KEY = new KeyMapping("key.easybuild.toggle",
            KeyConflictContext.IN_GAME, KeyModifier.CONTROL, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_S, CATEGORY);

    /** Text under the crosshair while build mode is on. */
    public static final IGuiOverlay HUD = (gui, g, partialTick, w, h) -> {
        Minecraft mc = Minecraft.getInstance();
        if (!ClientState.enabled || mc.options.hideGui || mc.player == null) return;
        String en = "Build: " + Shapes.MODES[ClientState.mode];
        String ar = "البناء: " + Shapes.MODES_AR[ClientState.mode];
        if (ClientState.mode != 0 && ClientState.first != null) {
            en += " (point 1 set)";
            ar += " (تم تحديد النقطة الأولى)";
        }
        g.drawCenteredString(mc.font, Component.literal(en), w / 2, h / 2 + 12, 0x55FFFF);
        g.drawCenteredString(mc.font, Component.literal(ar), w / 2, h / 2 + 22, 0xAAAAAA);
    };

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent e) {
        e.register(MENU_KEY);
        e.register(TOGGLE_KEY);
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "easybuild_hud", HUD);
    }
}
