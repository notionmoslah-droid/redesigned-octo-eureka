package com.abdou.easybuild;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;

public class BuildState {
    public boolean enabled = false;
    public int mode = 1;
    public boolean mx, mz, my;
    public BlockPos center;
    public int count = 0, dx = 2, dy = 0, dz = 0;
    public BlockPos first;
    public ResourceKey<Level> firstDim;
    public final Deque<UndoEntry> undo = new ArrayDeque<>();

    public boolean anyMirror() { return mx || mz || my; }

    public record Rec(BlockPos pos, BlockState old) {}
    public record UndoEntry(ResourceKey<Level> dim, List<Rec> blocks, Item item, boolean refund) {}
}
