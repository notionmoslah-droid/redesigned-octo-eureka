package com.abdou.easybuild.client;

import com.abdou.easybuild.ClientState;
import com.abdou.easybuild.Network;
import com.abdou.easybuild.Shapes;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Java version of the Bedrock form: English on the buttons, Arabic under each one. */
public class EasyBuildScreen extends Screen {
    private static final int W = 150, STEP = 32, GRAY = 0xAAAAAA;

    private record Caption(int x, int y, Supplier<Component> text) {}
    private final List<Caption> captions = new ArrayList<>();
    private int top;

    private boolean enabled = ClientState.enabled, mx = ClientState.mx, mz = ClientState.mz, my = ClientState.my;
    private int mode = ClientState.mode, count = ClientState.count;
    private int dx = ClientState.dx, dy = ClientState.dy, dz = ClientState.dz;
    private boolean setCenter = false;

    public EasyBuildScreen() {
        super(Component.literal("Easy build without items"));
    }

    @Override
    protected void init() {
        captions.clear();
        int cx = width / 2, lx = cx - 155, rx = cx + 5;
        top = Math.max(26, height / 2 - 96);

        // left column
        int y = top;
        toggle(lx, y, "Build mode", "تفعيل البناء (Ctrl+S)", () -> enabled, v -> enabled = v);
        y += STEP;
        addRenderableWidget(Button.builder(modeText(), b -> {
            mode = (mode + 1) % Shapes.MODES.length;
            b.setMessage(modeText());
        }).bounds(lx, y, W, 20).build());
        caption(lx, y, () -> Component.literal("الوضع: " + Shapes.MODES_AR[mode]));
        y += STEP;
        toggle(lx, y, "Mirror on X axis", "مرآة على محور X", () -> mx, v -> mx = v);
        y += STEP;
        toggle(lx, y, "Mirror on Z axis", "مرآة على محور Z", () -> mz, v -> mz = v);
        y += STEP;
        toggle(lx, y, "Mirror vertically (Y)", "مرآة عمودية (Y)", () -> my, v -> my = v);
        y += STEP;
        toggle(lx, y, "Set mirror center here", "ضع مركز المرآة عند موقعي", () -> setCenter, v -> setCenter = v);

        // right column
        y = top;
        stepper(rx, y, "Repeat", "عدد التكرار (0 = متوقف)", () -> count, v -> count = v, 0, 20);
        y += STEP;
        stepper(rx, y, "Offset X", "إزاحة التكرار X", () -> dx, v -> dx = v, -10, 10);
        y += STEP;
        stepper(rx, y, "Offset Y", "إزاحة التكرار Y", () -> dy, v -> dy = v, -10, 10);
        y += STEP;
        stepper(rx, y, "Offset Z", "إزاحة التكرار Z", () -> dz, v -> dz = v, -10, 10);
        y += STEP;
        addRenderableWidget(Button.builder(Component.literal("Undo last build"), b -> send(true))
                .bounds(rx, y, W, 20).build());
        caption(rx, y, () -> Component.literal("تراجع عن آخر بناء"));
        y += STEP;
        addRenderableWidget(Button.builder(Component.literal("§aSave"), b -> send(false))
                .bounds(rx, y, W, 20).build());
        caption(rx, y, () -> Component.literal("حفظ"));
    }

    private Component modeText() {
        return Component.literal("Mode: " + Shapes.MODES[mode]);
    }

    private static Component onOff(String name, boolean v) {
        return Component.literal(name + ": " + (v ? "§aON" : "§cOFF"));
    }

    private void caption(int x, int y, Supplier<Component> text) {
        captions.add(new Caption(x + W / 2, y + 22, text));
    }

    private void toggle(int x, int y, String en, String ar, BooleanSupplier get, Consumer<Boolean> set) {
        addRenderableWidget(Button.builder(onOff(en, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(onOff(en, get.getAsBoolean()));
        }).bounds(x, y, W, 20).build());
        caption(x, y, () -> Component.literal(ar + ": " + (get.getAsBoolean() ? "مفعّل" : "متوقف")));
    }

    private void stepper(int x, int y, String en, String ar, IntSupplier get, IntConsumer set, int min, int max) {
        Button label = Button.builder(Component.literal(en + ": " + get.getAsInt()), b -> {})
                .bounds(x + 22, y, W - 44, 20).build();
        label.active = false;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            set.accept(Math.max(min, get.getAsInt() - 1));
            label.setMessage(Component.literal(en + ": " + get.getAsInt()));
        }).bounds(x, y, 20, 20).build());
        addRenderableWidget(label);
        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            set.accept(Math.min(max, get.getAsInt() + 1));
            label.setMessage(Component.literal(en + ": " + get.getAsInt()));
        }).bounds(x + W - 20, y, 20, 20).build());
        caption(x, y, () -> Component.literal(ar));
    }

    private void send(boolean undo) {
        if (mode != ClientState.mode || !enabled) ClientState.first = null;
        ClientState.enabled = enabled;
        ClientState.mode = mode;
        ClientState.mx = mx; ClientState.mz = mz; ClientState.my = my;
        ClientState.count = count; ClientState.dx = dx; ClientState.dy = dy; ClientState.dz = dz;
        Network.CHANNEL.sendToServer(ClientState.packet(setCenter, undo));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, top - 22, 0xFFFFFF);
        g.drawCenteredString(font, Component.literal("بناء سهل بدون أدوات"), width / 2, top - 12, GRAY);
        super.render(g, mouseX, mouseY, partialTick);
        for (Caption c : captions) g.drawCenteredString(font, c.text().get(), c.x(), c.y(), GRAY);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
