package com.abdou.easybuild;

import net.minecraft.core.BlockPos;

/** Client copy of the settings (plain data, safe on both sides). */
public final class ClientState {
    public static boolean enabled, mx, mz, my;
    public static int mode, count, dx, dy, dz;
    public static BlockPos first, center;

    static { reset(); }

    public static void reset() {
        enabled = false; mode = 1; mx = mz = my = false;
        count = 0; dx = 2; dy = 0; dz = 0;
        first = null; center = null;
    }

    public static SettingsPacket packet(boolean setCenter, boolean undo) {
        return new SettingsPacket(enabled, mode, mx, mz, my, setCenter, count, dx, dy, dz, undo);
    }
}
