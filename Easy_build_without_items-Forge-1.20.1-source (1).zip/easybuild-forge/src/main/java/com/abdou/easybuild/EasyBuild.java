package com.abdou.easybuild;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(EasyBuild.MODID)
public class EasyBuild {
    public static final String MODID = "easybuild";

    public EasyBuild() {
        Network.register();
        MinecraftForge.EVENT_BUS.register(BuildHandler.class);
    }
}
