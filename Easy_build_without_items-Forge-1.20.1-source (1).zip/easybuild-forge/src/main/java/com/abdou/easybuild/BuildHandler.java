package com.abdou.easybuild;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BuildHandler {
    private static final int MAX_UNDO = 10;
    private static final Map<UUID, BuildState> STATES = new HashMap<>();
    private static final List<Pending> PENDING = new ArrayList<>();

    private record Pending(ServerPlayer player, ServerLevel level, BlockPos origin, BlockState state) {}

    public static BuildState get(Player p) {
        return STATES.computeIfAbsent(p.getUUID(), k -> new BuildState());
    }

    private static void bar(Player p, String en, String ar) {
        p.displayClientMessage(Component.literal(en + " §7| " + ar), true);
    }

    private static void sync(ServerPlayer p, BuildState s) {
        Network.sendTo(p, new SyncPacket(s.enabled, s.first, s.center));
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (e instanceof BlockEvent.EntityMultiPlaceEvent) return; // doors, beds...
        if (!(e.getEntity() instanceof ServerPlayer player)) return;
        if (!(e.getLevel() instanceof ServerLevel level)) return;
        if (!get(player).enabled) return;
        // run after vanilla finished placing (so item counts stay correct)
        PENDING.add(new Pending(player, level, e.getPos().immutable(), e.getPlacedBlock()));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || PENDING.isEmpty()) return;
        List<Pending> list = new ArrayList<>(PENDING);
        PENDING.clear();
        for (Pending pd : list) {
            if (!pd.player().isRemoved()) handle(pd);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        STATES.remove(e.getEntity().getUUID());
    }

    private static void handle(Pending pd) {
        ServerPlayer p = pd.player();
        ServerLevel level = pd.level();
        BlockPos origin = pd.origin();
        if (level.getBlockState(origin).getBlock() != pd.state().getBlock()) return; // placement was cancelled
        BuildState s = get(p);

        if (s.anyMirror() && s.center == null) {
            s.center = p.blockPosition().below();
            bar(p, "§bMirror center set at your position", "تم وضع مركز المرآة عند موقعك");
        }

        List<BlockPos> base = List.of(origin);
        if (s.mode != 0) {
            if (s.first != null && level.dimension().equals(s.firstDim)) {
                BlockPos a = s.first;
                s.first = null;
                base = Shapes.shape(s.mode, a, origin);
                if (base == null) {
                    bar(p, "§cArea too large", "المساحة كبيرة جدًا");
                    sync(p, s);
                    return;
                }
            } else {
                s.first = origin;
                s.firstDim = level.dimension();
                bar(p, "§eStart point set, place the second block", "تم تحديد النقطة الأولى، ضع البلوك الثاني");
            }
        }

        List<BlockPos> all = Shapes.repeat(Shapes.mirror(base, s.mx, s.mz, s.my, s.center), s.count, s.dx, s.dy, s.dz);
        build(p, level, s, all, pd.state(), origin);
        sync(p, s);
    }

    private static void build(ServerPlayer p, ServerLevel level, BuildState s, List<BlockPos> list,
                              BlockState state, BlockPos origin) {
        boolean truncated = false;
        if (list.size() > Shapes.MAX_BLOCKS) {
            list = list.subList(0, Shapes.MAX_BLOCKS);
            truncated = true;
        }
        boolean survival = !p.getAbilities().instabuild;
        Item item = state.getBlock().asItem();
        int budget = survival ? (item == Items.AIR ? 0 : countItem(p, item)) : Integer.MAX_VALUE;

        List<BuildState.Rec> rec = new ArrayList<>();
        rec.add(new BuildState.Rec(origin, Blocks.AIR.defaultBlockState())); // the block the player placed
        int placed = 0;
        boolean outOfBlocks = false;

        for (BlockPos pos : list) {
            if (pos.equals(origin)) continue;
            if (pos.getY() < level.getMinBuildHeight() || pos.getY() >= level.getMaxBuildHeight()) continue;
            if (!level.isLoaded(pos) || !level.mayInteract(p, pos)) continue;
            BlockState old = level.getBlockState(pos);
            if (old.equals(state)) continue;
            if (placed >= budget) { outOfBlocks = true; break; }
            rec.add(new BuildState.Rec(pos, old));
            level.setBlock(pos, Block.updateFromNeighbourShapes(state, level, pos), 3);
            placed++;
        }
        if (survival && placed > 0) takeItem(p, item, placed);

        s.undo.addLast(new BuildState.UndoEntry(level.dimension(), rec, item, survival && item != Items.AIR));
        if (s.undo.size() > MAX_UNDO) s.undo.pollFirst();

        if (outOfBlocks) bar(p, "§cNot enough blocks (+" + placed + ")", "البلوكات غير كافية");
        else if (truncated) bar(p, "§cLimited to the first " + Shapes.MAX_BLOCKS + " blocks", "تم الاكتفاء بأول " + Shapes.MAX_BLOCKS + " بلوك");
        else if (placed > 0) bar(p, "§a+" + placed + " blocks", "+" + placed + " بلوك");
    }

    public static void undoLast(ServerPlayer p) {
        BuildState s = get(p);
        BuildState.UndoEntry e = s.undo.pollLast();
        if (e == null) {
            bar(p, "§cNothing to undo", "لا يوجد ما يمكن التراجع عنه");
            return;
        }
        ServerLevel level = p.server.getLevel(e.dim());
        int back = 0;
        if (level != null) {
            for (BuildState.Rec r : e.blocks()) {
                if (!level.isLoaded(r.pos())) continue;
                if (level.getBlockState(r.pos()).getBlock().asItem() == e.item()) back++; // still there -> refund
                level.setBlock(r.pos(), r.old(), 3);
            }
        }
        if (e.refund() && back > 0) give(p, e.item(), back);
        bar(p, "§eUndone", "تم التراجع");
    }

    public static void applySettings(ServerPlayer p, SettingsPacket pk) {
        BuildState s = get(p);
        int mode = Mth.clamp(pk.mode, 0, Shapes.MODES.length - 1);
        boolean toggled = pk.enabled != s.enabled;
        if (mode != s.mode || !pk.enabled) s.first = null;
        s.enabled = pk.enabled;
        s.mode = mode;
        s.mx = pk.mx; s.mz = pk.mz; s.my = pk.my;
        s.count = Mth.clamp(pk.count, 0, 20);
        s.dx = Mth.clamp(pk.dx, -10, 10);
        s.dy = Mth.clamp(pk.dy, -10, 10);
        s.dz = Mth.clamp(pk.dz, -10, 10);
        if (pk.setCenter || (s.anyMirror() && s.center == null)) s.center = p.blockPosition().below();

        if (pk.undo) undoLast(p);
        else if (toggled) {
            if (s.enabled) bar(p, "§aBuild mode ON", "وضع البناء مفعّل");
            else bar(p, "§cBuild mode OFF", "وضع البناء متوقف");
        } else bar(p, "§aSettings saved", "تم حفظ الإعدادات");
        sync(p, s);
    }

    private static int countItem(ServerPlayer p, Item item) {
        Inventory inv = p.getInventory();
        int n = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (st.is(item)) n += st.getCount();
        }
        return n;
    }

    private static void takeItem(ServerPlayer p, Item item, int amount) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize() && amount > 0; i++) {
            ItemStack st = inv.getItem(i);
            if (st.is(item)) {
                int t = Math.min(amount, st.getCount());
                st.shrink(t);
                amount -= t;
            }
        }
        inv.setChanged();
    }

    private static void give(ServerPlayer p, Item item, int n) {
        int max = new ItemStack(item).getMaxStackSize();
        while (n > 0) {
            int c = Math.min(n, max);
            n -= c;
            ItemStack st = new ItemStack(item, c);
            if (!p.getInventory().add(st)) p.drop(st, false);
        }
    }
}
