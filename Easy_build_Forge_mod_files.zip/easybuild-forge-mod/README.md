# Easy build without items — Forge 1.20.1

## الأزرار
- **B**: فتح القائمة
- **Ctrl + S**: تشغيل/إيقاف وضع البناء (S وحدها هي زر الرجوع للخلف في جافا)
- يمكن تغيير الأزرار من: Options > Controls > Key Binds > Easy build

## الأوضاع
Normal (عادي)، Line (خط)، Wall (جدار)، Roof (سقف)، Filled Box (صندوق ممتلئ)
+ مرآة X / Z / Y، تكرار مع إزاحة، تراجع عن آخر 10 عمليات.
في وضع البقاء يأخذ البلوكات من الإنفنتوري، والتراجع يرجعها.

## صنع ملف jar
أضف ملف `.github/workflows/build.yml` بنفسك ثم ادخل Actions.
